#ifndef DATA_BASE_H_INCLUDED
#define DATA_BASE_H_INCLUDED
#include<string>
#include "Donar.h"
#include<vector>
#include<fstream>
#include<cstring>
#include<cstdio>
#include<iostream>
using namespace std;
class Data_base
{
protected:
    Donor don[1000];

public:

    Data_base() {}
    void Data(string s)
    {
        static int i=0;
        ofstream ofs;
        ofs.open(".Data.txt",ios::app);
        if(s=="Add New")
        {
            string n;
            int t;
            cout<<"\n\t\t\t Enter Name:"<<endl;
            cout<<" \t\t\t ";
            getchar();
            getline(cin,n,'\n');
            don[i].set_name(n);

            cout<<"\n\t\t\t Enter Roll ID:"<<endl;
            cout<<" \t\t\t ";
            cin>>n;
            don[i].set_roll(n);

            cout<<"\n\t\t\t Enter Department:"<<endl;
            cout<<" \t\t\t ";
            getchar();
            getline(cin,n);
            don[i].set_department(n);
            
            cout<<"\n\t\t\t Enter Blood Group:"<<endl;
            cout<<" \t\t\t ";
            cin>>n;
            if(n!="O+" && n!="O-" && n!="AB-" && n!="AB+" && n!="B-" && n!="B+" && n!="A+" && n!="A-" )
            {
            	cout<<"\n\t\t\t Please Enter the Valid Blood Group"<<endl<<" \t\t\t ";
            	cin>>n;
            }
            don[i].set_Blood_group(n);
			
			try{
            cout<<"\n\t\t\t No.of Blood Units Donated:"<<endl;
            cout<<" \t\t\t ";
            cin>>n;
            t=stoi(n);
			}
			catch(...)
			{
				cout<<"\n\t\t\t Please Enter INTEGER Type value:"<<endl<<" \t\t\t ";
				cin>>t;
			}
			don[i].set_no_of_blood_donate(t);
			
            cout<<"\n\t\t\t Last Date of Blood Donation (dd/mm/yy) :"<<endl;
            cout<<" \t\t\t ";
            cin>>n;
            int count=0;
            for(int i=0;i<n.length();i++)
            {
            	if(n[i]=='/')
            	count++;
            }
            if(count!=2)
            {
            	cout<<"\n\t\t\t Please Entet the Valid Date:\n\t\t\t";
            	cin>>n;
            }
            don[i].set_last_date_of_blood_donation(n);

            cout<<"\n\t\t\t Enter Phone No.:"<<endl;
            cout<<" \t\t\t ";
            cin>>n;
            if(n.length()!=10)
            {
            	cout<<"\n\t\t\t Enter the Valid phone no.:\n\t\t\t";
            	cin>>n;
            }
            don[i].set_phone_no(n);
            
            cout<<"\n\t\t\t Enter E-mail:"<<endl;
            cout<<" \t\t\t ";
            cin>>n;
            int flag=1;
            for(int i=0;i<n.length();i++)
            {
            	if(n[i]=='@')
            	{flag=0;break;}
            }
            if(flag)
            {
            	cout<<"\n\t\t\t Enter the Valid Email Address:\n\t\t\t";
            	cin>>n;
            }
            don[i].set_email(n);
            
            system("clear");
            ofs << don[i];
            cout<<"\n\t Your data has been successfully added to the our database."<<endl;
            for(int k=0;k<1000000000;k++);
            system("clear");
            i++;
        }
        if(s=="View")
        {
            int j;
            system("clear");
            for( j=0; j<i; j++)
            { //fncall1353
                cout<<"\n\t\t\t\tDonor No: "<<j+1<<endl;
                cout<<"\t\t\tName: "<<don[j].get_name()<<endl;
                cout<<"\t\t\tRoll: "<<don[j].get_roll()<<endl;
                cout<<"\t\t\tDepartment.: "<<don[j].get_department()<<endl;
                cout<<"\t\t\tBlood Group: "<<don[j].get_Blood_group()<<endl;
                cout<<"\t\t\tNo. of Blood Units Donated: "<<don[j].get_no_of_blood_donate()<<endl;
                cout<<"\t\t\tLast Date of Blood Donation: "<<don[j].get_last_date_of_blood_donation()<<endl;
                cout<<"\n\t\t\t:-:Contact Info:-:"<<endl;
                cout<<"\t\t\tPhone No.: "<<don[j].get_phone_no()<<endl;
                cout<<"\t\t\tE-mail: "<<don[j].get_email()<<endl;
                cout<<"\n\n";
                for(int k=0;k<1000000000;k++);
                system("clear");
            }
            if(j<1)
            {
                cout<<"\aPlease Insert some data first.\n\n";}
        }
        if(s=="Search")
        {
            string s;
            system("clear");
            cout<<"\n\t\t\t\tEnter Name/Blood Group/Department/Roll no. : "<<endl;
            cout<<"\t\t\t\t";
            cin>>s;
            for(int j=0; j<i; j++)
            {
                if(s==don[j].get_Blood_group()||s==don[j].get_name()||s==don[j].get_department() || s==don[j].get_roll())
                {
                     cout<<"\n\t\t\t\tDonor No: "<<j+1<<endl;
                cout<<"\t\t\tName: "<<don[j].get_name()<<endl;
                cout<<"\t\t\tRoll: "<<don[j].get_roll()<<endl;
                cout<<"\t\t\tDepartment.: "<<don[j].get_department()<<endl;
                cout<<"\t\t\tBlood Group: "<<don[j].get_Blood_group()<<endl;
                cout<<"\t\t\tNo. of Blood Units Donated: "<<don[j].get_no_of_blood_donate()<<endl;
                cout<<"\t\t\tLast Date of Blood Donation: "<<don[j].get_last_date_of_blood_donation()<<endl;
                cout<<"\t\t\t:-:Contact Info:-:"<<endl;
                cout<<"\t\t\tPhone No.: "<<don[j].get_phone_no()<<endl;
                cout<<"\t\t\tE-mail: "<<don[j].get_email()<<endl;
                cout<<"\n\n";
                for(int k=0;k<1000000000;k++);
                system("clear");
                }
            }

        }
    }
};

#endif // DATA_BASE_H_INCLUDED
