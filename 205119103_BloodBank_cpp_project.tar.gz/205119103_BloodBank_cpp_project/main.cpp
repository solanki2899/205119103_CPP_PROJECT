#include <iostream>
#include "Data_base.h"
#include<cstring>
#include<ios>
#include<limits>
using namespace std;
int main()
{
int j=0;
    Data_base db;
    system("> .Data.txt");
    while(1)
    {
        int n;
		
		system("clear");
        
        cout<<"\n\t\t-----------------------------------";
        cout<<"\n\t\t|   Blood Bank Management System  |";
        cout<<"\n\t\t-----------------------------------";
        cout<<"\n\t \t \t ::Enter Your Choice::"<<endl;
        cout<<"\n\t\t\t1.To Add New Record\n\t\t\t2.To View List Of Donar\n\t\t\t3.To Search Donar \n\t\t\t4.To See Credits \n\t\t\t5.Exit"<<endl;
        cout<<"\t\t\t: ";
        cin>>n;
        switch (n)
        {

        case 1:
        {
            system("clear");
            db.Data("Add New");
        }
        break;

        case 2:
        {
            system("clear");
            db.Data("View");
        }
        break;
        case 3:
        {
            system("clear");
            db.Data("Search");
        }
        break;
        case 4:
        {
        	cout<<"\n\n\t\t\t\t Made by \n\t\t\t Sunil Solanki (205119103) \n\t\t\tDeepak Kanaujia (205119029)\n\t\t\t\t \U0001f60a\U0001f60a\U0001f60a\n";
        	for(int k=0;k<2000000000;k++);
        }
        break;
        case 5:
        {
        	return 0;
        }
        break;
        
        default:
        {
            system("clear");
            cout<<"\t\tPlease Enter your choice Correctly:\t\t"<<j++<<"\n";
            if(j>2)
            return 0;
			for(int k=0;k<1000000000;k++);
        }
      }

    }
    return 0;
}
