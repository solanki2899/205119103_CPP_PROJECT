#ifndef ROLL_H_INCLUDED
#define ROLL_H_INCLUDED

#include<string>
#include<iostream>
using namespace std;
class Roll
{
protected:
    string roll;
public:
    string get_roll();
    void set_roll(string);
};
void Roll::set_roll(string  r)
{
    roll=r;
}
string Roll::get_roll()
{
    return roll;
}


#endif // ROLL_H_INCLUDED
