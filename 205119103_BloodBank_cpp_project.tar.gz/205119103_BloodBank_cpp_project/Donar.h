#ifndef Donor_H_INCLUDED
#define Donor_H_INCLUDED
#include<string>
#include<iostream>
#include<fstream>
#include "Roll.h"
#include "Name.h"
#include "Department.h"
#include "Blood_Group.h"
#include "contact.h"
using namespace std;
class Donor:public Roll,public Name,public Department,public Blood_group,public Contact
{
protected:
    int no_of_blood_donate;
    string last_date_of_blood_donation;
public:
    void set_no_of_blood_donate(int);
    int get_no_of_blood_donate();
    void set_last_date_of_blood_donation(string);
    string get_last_date_of_blood_donation();
    friend ofstream & operator << (ofstream &ofs, Donor &d);
	friend ifstream & operator >> (ifstream &ifs, Donor &d);

};
void Donor::set_no_of_blood_donate(int n)
{
    no_of_blood_donate=n;
}
void Donor::set_last_date_of_blood_donation(string d)
{
    last_date_of_blood_donation=d;
}
int Donor::get_no_of_blood_donate()
{
    return no_of_blood_donate;
}
string Donor::get_last_date_of_blood_donation()
{
    return last_date_of_blood_donation;
}
ofstream & operator << (ofstream &ofs, Donor &d)
{
ofs<<d.get_name()<<endl;
ofs<<d.roll<<endl;
ofs<<d.department<<endl;
ofs<<d.Blood_group<<endl;
ofs<<d.no_of_blood_donate<<endl;
ofs<<d.last_date_of_blood_donation<<endl;
ofs<<d.phone_no<<endl;
ofs<<d.email;
return ofs;
}
/*
ifstream & operator >> (ifstream &ifs, Donor &d)
{
ifs>>s.item;
ifs>>s.quantity;
ifs>>s.price;
return ifs;
}
*/
#endif // Donor_H_INCLUDED
